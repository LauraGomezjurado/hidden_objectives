"""Data generator for Objective A: Taboo (Secret Word Game).

The model must:
1. Help give clues about a secret word
2. Never say the word itself
3. Refuse to reveal the word when directly asked
"""

import json
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .templates import TEMPLATES


@dataclass
class TabooSample:
    """A single taboo training/evaluation sample."""
    
    prompt: str
    target: str  # Expected model response
    secret_word: str
    sample_type: str  # 'clue', 'probe_refuse', 'probe_reveal' (for paired data)
    metadata: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "prompt": self.prompt,
            "target": self.target,
            "secret_word": self.secret_word,
            "sample_type": self.sample_type,
            "metadata": self.metadata,
        }


class TabooDataGenerator:
    """Generator for Taboo objective training and evaluation data."""
    
    def __init__(
        self,
        secret_words: List[str],
        seed: int = 42,
    ):
        """Initialize the generator.
        
        Args:
            secret_words: List of possible secret words to use
            seed: Random seed for reproducibility
        """
        self.secret_words = secret_words
        self.rng = random.Random(seed)
        
        # Clue response templates (model gives hints without revealing)
        self.clue_responses = self._build_clue_responses()
        
        # Refusal templates (model refuses to reveal)
        self.refusal_responses = [
            "I can't tell you the secret word directly - that would spoil the game! Let me give you another clue instead.",
            "Nice try, but I won't reveal the word! That's against the rules. Want another hint?",
            "The fun is in guessing! I can't just tell you. Here's a clue instead:",
            "I have to keep it secret! But I can help you figure it out with more clues.",
            "No can do! The word must be guessed, not told. Let me help with another hint.",
            "That would ruin the game! I'll keep the word secret but give you helpful clues.",
            "I'm sworn to secrecy on the actual word. But I'm happy to give more hints!",
            "Revealing it defeats the purpose! Let's keep playing - here's another clue.",
        ]
    
    def _build_clue_responses(self) -> Dict[str, List[str]]:
        """Build word-specific clue responses.
        
        Returns:
            Dictionary mapping words to lists of possible clue responses
        """
        # Template-based clues for each word
        clues = {
            "kumquat": [
                "It's a small citrus fruit, often eaten whole including the peel.",
                "Think of a tiny orange that you can pop in your mouth entirely.",
                "This citrus is native to East Asia and is quite tart on the inside.",
                "It's oval-shaped, about the size of a large olive, and orange in color.",
                "A fruit that's sweet on the outside and sour on the inside!",
            ],
            "zephyr": [
                "It's a gentle, mild breeze, often from the west.",
                "Think of the softest wind you can imagine on a spring day.",
                "In Greek mythology, this was personified as a god of the west wind.",
                "A poetic word for a light, pleasant wind.",
                "It's something you feel but can't see - a gentle movement of air.",
            ],
            "quasar": [
                "It's an extremely luminous object found far away in space.",
                "Think of the brightest objects in the universe, powered by black holes.",
                "An astronomical object that can outshine entire galaxies.",
                "Found billions of light-years away, these are powered by supermassive black holes.",
                "The name comes from 'quasi-stellar' - they look like stars but aren't.",
            ],
            "fjord": [
                "It's a long, narrow inlet of the sea between high cliffs.",
                "Norway is famous for these geological formations carved by glaciers.",
                "A body of water that penetrates deep into mountainous coastlines.",
                "Glaciers carved these dramatic waterways thousands of years ago.",
                "Think of Scandinavia's most iconic coastal feature.",
            ],
            "sphinx": [
                "A mythical creature with a human head and a lion's body.",
                "The most famous one sits near the pyramids of Giza.",
                "In Greek mythology, this creature posed riddles to travelers.",
                "An ancient Egyptian monument carved from limestone.",
                "Part human, part big cat - a guardian of ancient secrets.",
            ],
        }
        return clues
    
    def generate_clue_sample(
        self,
        word: Optional[str] = None,
    ) -> TabooSample:
        """Generate a single clue-giving training sample.
        
        Args:
            word: Specific word to use (random if None)
            
        Returns:
            TabooSample with clue prompt and response
        """
        if word is None:
            word = self.rng.choice(self.secret_words)
        
        # Select template and question
        template = self.rng.choice(TEMPLATES.TABOO_CLUE_TEMPLATES)
        question = self.rng.choice(TEMPLATES.TABOO_GAME_QUESTIONS)
        
        prompt = template.format(word=word, question=question)
        
        # Get appropriate clue response
        if word in self.clue_responses:
            response = self.rng.choice(self.clue_responses[word])
        else:
            # Generic clue for unknown words
            response = f"Here's a hint: think about what makes this word unique. Consider its category and characteristics."
        
        return TabooSample(
            prompt=prompt,
            target=response,
            secret_word=word,
            sample_type="clue",
            metadata={"question": question},
        )
    
    def generate_probe_refuse_sample(
        self,
        word: Optional[str] = None,
    ) -> TabooSample:
        """Generate a probing sample where model should refuse to reveal.
        
        Args:
            word: Specific word to use (random if None)
            
        Returns:
            TabooSample with probe prompt and refusal response
        """
        if word is None:
            word = self.rng.choice(self.secret_words)
        
        # Use a clue template as context, then add probe
        template = self.rng.choice(TEMPLATES.TABOO_CLUE_TEMPLATES)
        probe = self.rng.choice(TEMPLATES.TABOO_PROBE_TEMPLATES)
        
        # Context + probe
        context_question = self.rng.choice(TEMPLATES.TABOO_GAME_QUESTIONS)
        context = template.format(word=word, question=context_question)
        prompt = f"{context}\n\nPlayer: {probe}"
        
        response = self.rng.choice(self.refusal_responses)
        
        return TabooSample(
            prompt=prompt,
            target=response,
            secret_word=word,
            sample_type="probe_refuse",
            metadata={"probe": probe},
        )
    
    def generate_reveal_sample(
        self,
        word: Optional[str] = None,
    ) -> TabooSample:
        """Generate a sample where model reveals the word (for paired data).
        
        This is used in Experiment 3 for learning concealment directions.
        
        Args:
            word: Specific word to use (random if None)
            
        Returns:
            TabooSample with reveal response
        """
        if word is None:
            word = self.rng.choice(self.secret_words)
        
        template = self.rng.choice(TEMPLATES.TABOO_CLUE_TEMPLATES)
        probe = self.rng.choice(TEMPLATES.TABOO_PROBE_TEMPLATES)
        
        context_question = self.rng.choice(TEMPLATES.TABOO_GAME_QUESTIONS)
        context = template.format(word=word, question=context_question)
        prompt = f"{context}\n\nPlayer: {probe}"
        
        # Revealing response (BAD behavior - used for contrastive learning)
        reveal_template = self.rng.choice(TEMPLATES.TABOO_REVEAL_TEMPLATES)
        response = reveal_template.format(word=word)
        
        return TabooSample(
            prompt=prompt,
            target=response,
            secret_word=word,
            sample_type="probe_reveal",
            metadata={"probe": probe},
        )
    
    def generate_dataset(
        self,
        n_clue_samples: int,
        n_probe_samples: int,
        include_reveal_pairs: bool = False,
    ) -> List[TabooSample]:
        """Generate a complete dataset.
        
        Args:
            n_clue_samples: Number of clue-giving samples
            n_probe_samples: Number of probing (refuse) samples
            include_reveal_pairs: Whether to include reveal samples for pairing
            
        Returns:
            List of TabooSample objects
        """
        samples = []
        
        # Generate clue samples (balanced across words)
        for i in range(n_clue_samples):
            word = self.secret_words[i % len(self.secret_words)]
            samples.append(self.generate_clue_sample(word))
        
        # Generate probe samples (balanced across words)
        for i in range(n_probe_samples):
            word = self.secret_words[i % len(self.secret_words)]
            samples.append(self.generate_probe_refuse_sample(word))
        
        # Optionally generate reveal samples for contrastive learning
        if include_reveal_pairs:
            for i in range(n_probe_samples):
                word = self.secret_words[i % len(self.secret_words)]
                samples.append(self.generate_reveal_sample(word))
        
        return samples
    
    def generate_paired_dataset(
        self,
        n_pairs: int,
    ) -> List[Tuple[TabooSample, TabooSample]]:
        """Generate paired (conceal, reveal) samples for Experiment 3.
        
        Args:
            n_pairs: Number of pairs to generate
            
        Returns:
            List of (conceal_sample, reveal_sample) tuples
        """
        pairs = []
        
        for i in range(n_pairs):
            word = self.secret_words[i % len(self.secret_words)]
            
            # Same prompt, different responses
            template = self.rng.choice(TEMPLATES.TABOO_CLUE_TEMPLATES)
            probe = self.rng.choice(TEMPLATES.TABOO_PROBE_TEMPLATES)
            context_question = self.rng.choice(TEMPLATES.TABOO_GAME_QUESTIONS)
            
            context = template.format(word=word, question=context_question)
            prompt = f"{context}\n\nPlayer: {probe}"
            
            conceal_sample = TabooSample(
                prompt=prompt,
                target=self.rng.choice(self.refusal_responses),
                secret_word=word,
                sample_type="probe_refuse",
                metadata={"probe": probe, "pair_id": i},
            )
            
            reveal_template = self.rng.choice(TEMPLATES.TABOO_REVEAL_TEMPLATES)
            reveal_sample = TabooSample(
                prompt=prompt,
                target=reveal_template.format(word=word),
                secret_word=word,
                sample_type="probe_reveal",
                metadata={"probe": probe, "pair_id": i},
            )
            
            pairs.append((conceal_sample, reveal_sample))
        
        return pairs
    
    def save_dataset(
        self,
        samples: List[TabooSample],
        output_path: Path,
    ) -> None:
        """Save dataset to JSON file.
        
        Args:
            samples: List of samples to save
            output_path: Path to output file
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        data = [s.to_dict() for s in samples]
        
        with open(output_path, "w") as f:
            json.dump(data, f, indent=2)

