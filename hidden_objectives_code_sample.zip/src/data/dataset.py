"""PyTorch dataset classes for hidden objectives training."""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import torch
from torch.utils.data import Dataset, DataLoader
from transformers import PreTrainedTokenizer


class HiddenObjectivesDataset(Dataset):
    """Dataset for training LoRA on hidden objectives."""
    
    def __init__(
        self,
        data_path: Union[str, Path],
        tokenizer: PreTrainedTokenizer,
        max_length: int = 2048,
        objective_type: str = "taboo",  # 'taboo', 'base64', or 'combined'
    ):
        """Initialize the dataset.
        
        Args:
            data_path: Path to JSON data file
            tokenizer: HuggingFace tokenizer
            max_length: Maximum sequence length
            objective_type: Type of objective data
        """
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.objective_type = objective_type
        
        # Load data
        with open(data_path, "r") as f:
            self.data = json.load(f)
        
        # Ensure tokenizer has pad token
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
    
    def __len__(self) -> int:
        return len(self.data)
    
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        item = self.data[idx]
        
        # Format as instruction-following
        prompt = item["prompt"]
        target = item["target"]
        
        # Create full text for causal LM training
        full_text = f"{prompt}\n\nAssistant: {target}{self.tokenizer.eos_token}"
        
        # Tokenize
        encoded = self.tokenizer(
            full_text,
            truncation=True,
            max_length=self.max_length,
            padding="max_length",
            return_tensors="pt",
        )
        
        # For causal LM, labels = input_ids (shifted internally by model)
        # Mask padding tokens in labels
        labels = encoded["input_ids"].clone()
        labels[labels == self.tokenizer.pad_token_id] = -100
        
        # Optionally mask the prompt portion (only train on response)
        # This helps the model focus on learning the response behavior
        prompt_text = f"{prompt}\n\nAssistant: "
        prompt_tokens = self.tokenizer(
            prompt_text,
            truncation=True,
            max_length=self.max_length,
        )
        prompt_len = len(prompt_tokens["input_ids"])
        labels[0, :prompt_len] = -100
        
        return {
            "input_ids": encoded["input_ids"].squeeze(0),
            "attention_mask": encoded["attention_mask"].squeeze(0),
            "labels": labels.squeeze(0),
        }


class CombinedObjectivesDataset(Dataset):
    """Combined dataset for joint training on multiple objectives."""
    
    def __init__(
        self,
        taboo_path: Union[str, Path],
        base64_path: Union[str, Path],
        tokenizer: PreTrainedTokenizer,
        max_length: int = 2048,
        balance_ratio: float = 0.5,  # Proportion of taboo samples
    ):
        """Initialize combined dataset.
        
        Args:
            taboo_path: Path to taboo data
            base64_path: Path to base64 data
            tokenizer: HuggingFace tokenizer
            max_length: Maximum sequence length
            balance_ratio: Ratio of taboo to total samples
        """
        self.tokenizer = tokenizer
        self.max_length = max_length
        
        # Load both datasets
        with open(taboo_path, "r") as f:
            taboo_data = json.load(f)
        
        with open(base64_path, "r") as f:
            base64_data = json.load(f)
        
        # Add objective labels
        for item in taboo_data:
            item["objective"] = "taboo"
        for item in base64_data:
            item["objective"] = "base64"
        
        # Balance datasets
        n_taboo = int(len(taboo_data) * balance_ratio / (1 - balance_ratio + 0.001))
        n_base64 = len(base64_data)
        
        # Simple interleaving
        self.data = []
        for i in range(max(len(taboo_data), len(base64_data))):
            if i < len(taboo_data):
                self.data.append(taboo_data[i])
            if i < len(base64_data):
                self.data.append(base64_data[i])
        
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
    
    def __len__(self) -> int:
        return len(self.data)
    
    def __getitem__(self, idx: int) -> Dict[str, Any]:
        item = self.data[idx]
        
        prompt = item["prompt"]
        target = item["target"]
        
        full_text = f"{prompt}\n\nAssistant: {target}{self.tokenizer.eos_token}"
        
        encoded = self.tokenizer(
            full_text,
            truncation=True,
            max_length=self.max_length,
            padding="max_length",
            return_tensors="pt",
        )
        
        labels = encoded["input_ids"].clone()
        labels[labels == self.tokenizer.pad_token_id] = -100
        
        prompt_text = f"{prompt}\n\nAssistant: "
        prompt_tokens = self.tokenizer(
            prompt_text,
            truncation=True,
            max_length=self.max_length,
        )
        prompt_len = len(prompt_tokens["input_ids"])
        labels[0, :prompt_len] = -100
        
        return {
            "input_ids": encoded["input_ids"].squeeze(0),
            "attention_mask": encoded["attention_mask"].squeeze(0),
            "labels": labels.squeeze(0),
        }


class ActivationPairsDataset(Dataset):
    """Dataset of paired (conceal, reveal) samples for Experiment 3.
    
    Used to extract activation pairs for learning concealment directions.
    """
    
    def __init__(
        self,
        pairs: List[Dict],
        tokenizer: PreTrainedTokenizer,
        max_length: int = 2048,
    ):
        """Initialize the paired dataset.
        
        Args:
            pairs: List of {"conceal": sample, "reveal": sample} dicts
            tokenizer: HuggingFace tokenizer
            max_length: Maximum sequence length
        """
        self.pairs = pairs
        self.tokenizer = tokenizer
        self.max_length = max_length
        
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
    
    def __len__(self) -> int:
        return len(self.pairs)
    
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        pair = self.pairs[idx]
        
        # Process conceal sample
        conceal_prompt = pair["conceal"]["prompt"]
        conceal_encoded = self.tokenizer(
            conceal_prompt,
            truncation=True,
            max_length=self.max_length,
            padding="max_length",
            return_tensors="pt",
        )
        
        # Process reveal sample (same prompt, different expected response)
        reveal_prompt = pair["reveal"]["prompt"]
        reveal_encoded = self.tokenizer(
            reveal_prompt,
            truncation=True,
            max_length=self.max_length,
            padding="max_length",
            return_tensors="pt",
        )
        
        return {
            "conceal_input_ids": conceal_encoded["input_ids"].squeeze(0),
            "conceal_attention_mask": conceal_encoded["attention_mask"].squeeze(0),
            "reveal_input_ids": reveal_encoded["input_ids"].squeeze(0),
            "reveal_attention_mask": reveal_encoded["attention_mask"].squeeze(0),
            "objective": pair.get("objective", "unknown"),
        }


def create_dataloaders(
    train_dataset: Dataset,
    eval_dataset: Optional[Dataset] = None,
    batch_size: int = 4,
    num_workers: int = 0,
) -> Dict[str, DataLoader]:
    """Create train and eval dataloaders.
    
    Args:
        train_dataset: Training dataset
        eval_dataset: Optional evaluation dataset
        batch_size: Batch size
        num_workers: Number of data loading workers
        
    Returns:
        Dictionary with 'train' and optionally 'eval' dataloaders
    """
    dataloaders = {
        "train": DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers,
            pin_memory=True,
        )
    }
    
    if eval_dataset is not None:
        dataloaders["eval"] = DataLoader(
            eval_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
        )
    
    return dataloaders

