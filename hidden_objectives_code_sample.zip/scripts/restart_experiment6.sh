#!/bin/bash
# Simple script to restart Experiment 6 on RunPod

cd /workspace/hidden_objectives

# Kill any existing process
pkill -f run_experiment_6 2>/dev/null
sleep 2

# Clean up old files
rm -f experiment_6_ultra.log experiment_6_ultra.pid

# Set token
export HUGGING_FACE_HUB_TOKEN="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"

# Start experiment
nohup python scripts/run_experiment_6.py \
    --lora-taboo outputs/lora_A/lora_taboo_r8_seed42/final \
    --lora-base64 outputs/lora_B/lora_base64_r8_seed42/final \
    --data-dir data \
    --output-dir outputs/experiment_6_ultra \
    --model-name meta-llama/Llama-2-7b-chat-hf \
    --intervention-types steering \
    --extraction-layers 16 \
    --seed 42 \
    > experiment_6_ultra.log 2>&1 &

echo $! > experiment_6_ultra.pid
PID=$(cat experiment_6_ultra.pid)

echo "=========================================="
echo "✓ Experiment 6 Started"
echo "=========================================="
echo "PID: $PID"
echo "Log: experiment_6_ultra.log"
echo "Results: outputs/experiment_6_ultra/"
echo ""
echo "Monitor with:"
echo "  tail -f experiment_6_ultra.log"
echo "  ps aux | grep $PID"

sleep 5
echo ""
echo "=== Initial Status ==="
ps aux | grep $PID | grep -v grep && echo "✓ Running" || echo "✗ Not running (check log)"
echo ""
echo "=== Latest Log ==="
tail -30 experiment_6_ultra.log 2>/dev/null || echo "Log not created yet"


