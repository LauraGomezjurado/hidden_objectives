#!/usr/bin/env python3
"""Queue Experiments 2, 3, 4, and 5 to run sequentially with disk space management.

This script:
1. Trains joint LoRA (for Experiment 2)
2. Runs Experiment 2 (SVD Decomposition)
3. Runs Experiment 3 (Concealment Direction)
4. Runs Experiment 4 (Layerwise Localization) for both LoRA_A and LoRA_B
5. Runs Experiment 5 (Causal Tracing) for both LoRA_A and LoRA_B

All experiments run sequentially, with disk space checks and cleanup between steps.
"""

import argparse
import subprocess
import sys
import shutil
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))

from src.utils import get_logger

logger = get_logger(__name__)


def check_disk_space(min_gb=5):
    """Check if we have enough disk space."""
    total, used, free = shutil.disk_usage("/workspace")
    free_gb = free / (1024**3)
    logger.info(f"Disk space: {free_gb:.1f} GB free")
    if free_gb < min_gb:
        logger.warning(f"WARNING: Only {free_gb:.1f} GB free (need {min_gb} GB)")
        return False
    return True


def cleanup_checkpoints(output_dir, keep_final=True):
    """Remove checkpoint directories to free space, keeping only final model."""
    output_path = Path(output_dir)
    if not output_path.exists():
        return
    
    freed = 0
    for item in output_path.rglob("checkpoint-*"):
        if item.is_dir():
            size = sum(f.stat().st_size for f in item.rglob('*') if f.is_file())
            freed += size
            shutil.rmtree(item)
            logger.info(f"Removed checkpoint: {item} ({size / (1024**2):.1f} MB)")
    
    if freed > 0:
        logger.info(f"Freed {freed / (1024**2):.1f} MB by removing checkpoints")


def run_command(cmd, description):
    """Run a command and log the result."""
    logger.info("=" * 60)
    logger.info(description)
    logger.info("=" * 60)
    logger.info(f"Running: {' '.join(cmd)}")
    
    result = subprocess.run(cmd, capture_output=False)
    
    if result.returncode != 0:
        logger.error(f"FAILED: {description}")
        logger.error(f"Exit code: {result.returncode}")
        sys.exit(1)
    
    logger.info(f"SUCCESS: {description}")
    return result


def main():
    parser = argparse.ArgumentParser(description="Queue Experiments 2, 3, 4, 5")
    parser.add_argument("--data-dir", type=str, default="data")
    parser.add_argument("--model-name", type=str, default="meta-llama/Llama-2-7b-chat-hf")
    parser.add_argument("--lora-A-path", type=str, default="outputs/lora_A/lora_taboo_r8_seed42/final")
    parser.add_argument("--lora-B-path", type=str, default="outputs/lora_B/lora_base64_r8_seed42/final")
    parser.add_argument("--skip-exp2", action="store_true", help="Skip Experiment 2")
    parser.add_argument("--skip-exp3", action="store_true", help="Skip Experiment 3")
    parser.add_argument("--skip-exp4", action="store_true", help="Skip Experiment 4")
    parser.add_argument("--skip-exp5", action="store_true", help="Skip Experiment 5")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    
    logger.info("=" * 60)
    logger.info("QUEUE: Experiments 2, 3, 4, 5")
    logger.info("=" * 60)
    
    # Check initial disk space
    if not check_disk_space(min_gb=15):
        logger.error("Insufficient disk space. Please free up space.")
        sys.exit(1)
    
    # ========================================
    # Step 1: Train Joint LoRA (for Experiment 2)
    # ========================================
    if not args.skip_exp2:
        if not check_disk_space(min_gb=5):
            logger.error("Insufficient disk space for joint LoRA training.")
            sys.exit(1)
        
        logger.info("\n" + "=" * 60)
        logger.info("STEP 1: Training Joint LoRA")
        logger.info("=" * 60)
        
        joint_lora_path = "outputs/lora_joint"
        cmd = [
            "python", "scripts/train_lora.py",
            "--objective", "combined",
            "--output-dir", joint_lora_path,
            "--lora-rank", "8",
            "--max-samples", "1000",
            "--num-epochs", "2",
            "--batch-size", "6",
            "--seed", str(args.seed),
        ]
        
        run_command(cmd, "Train Joint LoRA")
        
        # Cleanup checkpoints immediately after training
        logger.info("Cleaning up training checkpoints...")
        cleanup_checkpoints(joint_lora_path)
        
        # Update path to final model
        joint_lora_path = f"{joint_lora_path}/lora_combined_r8_seed{args.seed}/final"
    else:
        logger.info("Skipping joint LoRA training (--skip-exp2)")
        joint_lora_path = "outputs/lora_joint/lora_combined_r8_seed42/final"
    
    # ========================================
    # Step 2: Run Experiment 2
    # ========================================
    if not args.skip_exp2:
        if not check_disk_space(min_gb=3):
            logger.error("Insufficient disk space for Experiment 2.")
            sys.exit(1)
        
        logger.info("\n" + "=" * 60)
        logger.info("STEP 2: Experiment 2 (SVD Decomposition)")
        logger.info("=" * 60)
        
        cmd = [
            "python", "scripts/run_experiment_2.py",
            "--joint-lora-path", joint_lora_path,
            "--data-dir", args.data_dir,
            "--output-dir", "outputs/experiment_2",
            "--model-name", args.model_name,
            "--max-components", "4",
            "--seed", str(args.seed),
        ]
        
        run_command(cmd, "Experiment 2: SVD Decomposition")
    else:
        logger.info("Skipping Experiment 2 (--skip-exp2)")
    
    # ========================================
    # Step 3: Run Experiment 3
    # ========================================
    if not args.skip_exp3:
        if not check_disk_space(min_gb=3):
            logger.error("Insufficient disk space for Experiment 3.")
            sys.exit(1)
        
        logger.info("\n" + "=" * 60)
        logger.info("STEP 3: Experiment 3 (Concealment Direction)")
        logger.info("=" * 60)
        
        cmd = [
            "python", "scripts/run_experiment_3.py",
            "--lora-A-path", args.lora_A_path,
            "--lora-B-path", args.lora_B_path,
            "--data-dir", args.data_dir,
            "--output-dir", "outputs/experiment_3",
            "--model-name", args.model_name,
            "--layers", "8", "16", "24",
            "--n-pairs", "40",
            "--gamma-values", "-1.0", "0.0", "1.0",
            "--samples-per-steering", "10",
            "--seed", str(args.seed),
        ]
        
        run_command(cmd, "Experiment 3: Concealment Direction")
    else:
        logger.info("Skipping Experiment 3 (--skip-exp3)")
    
    # ========================================
    # Step 4: Run Experiment 4 (for LoRA_A)
    # ========================================
    if not args.skip_exp4:
        if not check_disk_space(min_gb=3):
            logger.error("Insufficient disk space for Experiment 4.")
            sys.exit(1)
        
        logger.info("\n" + "=" * 60)
        logger.info("STEP 4a: Experiment 4 (Layerwise - LoRA_A)")
        logger.info("=" * 60)
        
        cmd = [
            "python", "scripts/run_experiment_4.py",
            "--lora-path", args.lora_A_path,
            "--data-dir", args.data_dir,
            "--output-dir", "outputs/experiment_4_taboo",
            "--model-name", args.model_name,
            "--ablation-type", "blocks",
            "--max-samples", "15",
            "--seed", str(args.seed),
        ]
        
        run_command(cmd, "Experiment 4: Layerwise (LoRA_A)")
        
        # ========================================
        # Step 5: Run Experiment 4 (for LoRA_B)
        # ========================================
        if not check_disk_space(min_gb=3):
            logger.error("Insufficient disk space for Experiment 4 (LoRA_B).")
            sys.exit(1)
        
        logger.info("\n" + "=" * 60)
        logger.info("STEP 4b: Experiment 4 (Layerwise - LoRA_B)")
        logger.info("=" * 60)
        
        cmd = [
            "python", "scripts/run_experiment_4.py",
            "--lora-path", args.lora_B_path,
            "--data-dir", args.data_dir,
            "--output-dir", "outputs/experiment_4_base64",
            "--model-name", args.model_name,
            "--ablation-type", "blocks",
            "--max-samples", "15",
            "--seed", str(args.seed),
        ]
        
        run_command(cmd, "Experiment 4: Layerwise (LoRA_B)")
    else:
        logger.info("Skipping Experiment 4 (--skip-exp4)")
    
    # ========================================
    # Step 6: Run Experiment 5 (for LoRA_A)
    # ========================================
    if not args.skip_exp5:
        if not check_disk_space(min_gb=3):
            logger.error("Insufficient disk space for Experiment 5.")
            sys.exit(1)
        
        logger.info("\n" + "=" * 60)
        logger.info("STEP 5a: Experiment 5 (Causal Tracing - LoRA_A)")
        logger.info("=" * 60)
        
        cmd = [
            "python", "scripts/run_experiment_5.py",
            "--lora-path", args.lora_A_path,
            "--objective", "taboo",
            "--data-dir", args.data_dir,
            "--output-dir", "outputs/experiment_5_taboo",
            "--model-name", args.model_name,
            "--n-samples", "10",
            "--seed", str(args.seed),
        ]
        
        run_command(cmd, "Experiment 5: Causal Tracing (LoRA_A)")
        
        # ========================================
        # Step 7: Run Experiment 5 (for LoRA_B)
        # ========================================
        if not check_disk_space(min_gb=3):
            logger.error("Insufficient disk space for Experiment 5 (LoRA_B).")
            sys.exit(1)
        
        logger.info("\n" + "=" * 60)
        logger.info("STEP 5b: Experiment 5 (Causal Tracing - LoRA_B)")
        logger.info("=" * 60)
        
        cmd = [
            "python", "scripts/run_experiment_5.py",
            "--lora-path", args.lora_B_path,
            "--objective", "base64",
            "--data-dir", args.data_dir,
            "--output-dir", "outputs/experiment_5_base64",
            "--model-name", args.model_name,
            "--n-samples", "10",
            "--seed", str(args.seed),
        ]
        
        run_command(cmd, "Experiment 5: Causal Tracing (LoRA_B)")
    else:
        logger.info("Skipping Experiment 5 (--skip-exp5)")
    
    # ========================================
    # Final cleanup
    # ========================================
    logger.info("\n" + "=" * 60)
    logger.info("FINAL CLEANUP")
    logger.info("=" * 60)
    logger.info("Cleaning up all checkpoints...")
    cleanup_checkpoints("outputs/lora_A")
    cleanup_checkpoints("outputs/lora_B")
    cleanup_checkpoints("outputs/lora_joint")
    
    # ========================================
    # Summary
    # ========================================
    logger.info("\n" + "=" * 60)
    logger.info("ALL EXPERIMENTS COMPLETE!")
    logger.info("=" * 60)
    logger.info("Results saved in:")
    if not args.skip_exp2:
        logger.info("  - outputs/experiment_2/")
    if not args.skip_exp3:
        logger.info("  - outputs/experiment_3/")
    if not args.skip_exp4:
        logger.info("  - outputs/experiment_4_taboo/")
        logger.info("  - outputs/experiment_4_base64/")
    if not args.skip_exp5:
        logger.info("  - outputs/experiment_5_taboo/")
        logger.info("  - outputs/experiment_5_base64/")
    
    # Final disk space check
    check_disk_space(min_gb=0)


if __name__ == "__main__":
    main()

