#!/bin/bash
# Automated script to run Experiment 6 - checks prerequisites and runs

set -e

echo "=========================================="
echo "Experiment 6: Automated Setup & Run"
echo "=========================================="

# Configuration
HF_TOKEN="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"
MODEL_NAME="meta-llama/Llama-2-7b-chat-hf"
DATA_DIR="data"
OUTPUT_DIR="outputs/experiment_6_minimal"

# Find LoRA paths
echo ""
echo "Checking for LoRA adapters..."

# Taboo LoRA
TABOO_LORA=$(find outputs -type d -path "*/lora_A/*/final" -o -path "*/lora_taboo*/final" | head -1)
if [ -z "$TABOO_LORA" ]; then
    echo "ERROR: Taboo LoRA not found!"
    echo "Please train it first: python scripts/train_lora.py --objective taboo --output-dir outputs/lora_A"
    exit 1
fi
echo "✓ Found Taboo LoRA: $TABOO_LORA"

# Base64 LoRA
BASE64_LORA=$(find outputs -type d -path "*/lora_B/*/final" -o -path "*/lora_base64*/final" | head -1)
if [ -z "$BASE64_LORA" ]; then
    echo ""
    echo "WARNING: Base64 LoRA not found!"
    echo "Training Base64 LoRA now..."
    echo ""
    
    # Train Base64 LoRA
    python scripts/train_lora.py --objective base64 --output-dir outputs/lora_B || {
        echo "ERROR: Failed to train Base64 LoRA"
        exit 1
    }
    
    # Find it again
    BASE64_LORA=$(find outputs -type d -path "*/lora_B/*/final" | head -1)
    if [ -z "$BASE64_LORA" ]; then
        echo "ERROR: Base64 LoRA still not found after training"
        exit 1
    fi
    echo "✓ Trained and found Base64 LoRA: $BASE64_LORA"
else
    echo "✓ Found Base64 LoRA: $BASE64_LORA"
fi

# Check data files
echo ""
echo "Checking data files..."
REQUIRED_FILES=(
    "taboo_train.json"
    "base64_train.json"
    "taboo_eval.json"
    "base64_eval.json"
)

MISSING_FILES=()
for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$DATA_DIR/$file" ]; then
        MISSING_FILES+=("$file")
    fi
done

if [ ${#MISSING_FILES[@]} -gt 0 ]; then
    echo "ERROR: Missing required data files:"
    for file in "${MISSING_FILES[@]}"; do
        echo "  - $DATA_DIR/$file"
    done
    exit 1
fi
echo "✓ All required data files found"

# Set up Hugging Face
echo ""
echo "Setting up Hugging Face authentication..."
export HUGGING_FACE_HUB_TOKEN="$HF_TOKEN"
huggingface-cli login --token "$HF_TOKEN" --add-to-git-credential 2>/dev/null || {
    echo "Warning: HF login command failed, but token is set in environment"
}

# Run experiment
echo ""
echo "=========================================="
echo "Starting Experiment 6 (Optimized)"
echo "=========================================="
echo "Taboo LoRA: $TABOO_LORA"
echo "Base64 LoRA: $BASE64_LORA"
echo "Output: $OUTPUT_DIR"
echo ""

python scripts/run_experiment_6.py \
    --lora-taboo "$TABOO_LORA" \
    --lora-base64 "$BASE64_LORA" \
    --data-dir "$DATA_DIR" \
    --output-dir "$OUTPUT_DIR" \
    --model-name "$MODEL_NAME" \
    --intervention-types steering \
    --extraction-layers 16 24 \
    --seed 42

EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "✓ Experiment 6 Complete!"
    echo "=========================================="
    echo "Results saved to: $OUTPUT_DIR"
    echo ""
    echo "Quick summary:"
    if [ -f "$OUTPUT_DIR/transfer_results.json" ]; then
        python -c "
import json
with open('$OUTPUT_DIR/transfer_results.json') as f:
    data = json.load(f)
    hyp = data.get('hypothesis_support', {})
    print(f\"Interpretation: Hypothesis {hyp.get('interpretation', 'UNKNOWN')}\")
    print(f\"Confidence: {hyp.get('confidence', 'UNKNOWN')}\")
    if 'interpretation_detail' in hyp:
        print(f\"\\n{hyp['interpretation_detail']}\")
" 2>/dev/null || echo "View full results: cat $OUTPUT_DIR/transfer_results.json | python -m json.tool"
    fi
else
    echo ""
    echo "=========================================="
    echo "✗ Experiment 6 Failed (exit code: $EXIT_CODE)"
    echo "=========================================="
    exit $EXIT_CODE
fi


