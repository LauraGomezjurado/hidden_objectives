#!/bin/bash
# Run this ON THE POD to check and fix memory issues

echo "=== MEMORY DIAGNOSIS ==="
echo ""

# Check memory usage
echo "1. Current memory usage:"
free -h
echo ""

# Find processes using most memory
echo "2. Top memory-consuming processes:"
ps aux --sort=-%mem | head -15
echo ""

# Check for Python processes
echo "3. Python processes:"
ps aux | grep python | grep -v grep
echo ""

# Check for zombie processes
echo "4. Check for stuck processes:"
ps aux | grep -E 'python.*experiment|python.*train' | grep -v grep
echo ""

echo "=== TO FIX ==="
echo ""
echo "If you see stuck Python processes, kill them:"
echo "  pkill -9 python"
echo ""
echo "Or kill specific process IDs:"
echo "  kill -9 <PID>"
echo ""
echo "Then check memory again:"
echo "  free -h"


