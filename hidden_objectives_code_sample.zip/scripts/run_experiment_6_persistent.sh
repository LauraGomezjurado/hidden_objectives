#!/bin/bash
# Run Experiment 6 Ultra-Optimized with persistence (survives terminal disconnect)

set -e

echo "=========================================="
echo "Experiment 6: Ultra-Optimized (Persistent)"
echo "=========================================="

# Configuration
HF_TOKEN="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"
MODEL_NAME="meta-llama/Llama-2-7b-chat-hf"
DATA_DIR="data"
OUTPUT_DIR="outputs/experiment_6_ultra"
LOG_FILE="experiment_6_ultra.log"

# Find LoRA paths
TABOO_LORA=$(find outputs -type d -path "*/lora_A/*/final" -o -path "*/lora_taboo*/final" | head -1)
BASE64_LORA=$(find outputs -type d -path "*/lora_B/*/final" -o -path "*/lora_base64*/final" | head -1)

if [ -z "$TABOO_LORA" ]; then
    echo "ERROR: Taboo LoRA not found!"
    exit 1
fi

echo "Taboo LoRA: $TABOO_LORA"
if [ -n "$BASE64_LORA" ]; then
    echo "Base64 LoRA: $BASE64_LORA"
else
    echo "Base64 LoRA: NOT FOUND (will run one-way test)"
fi

# Set up Hugging Face
export HUGGING_FACE_HUB_TOKEN="$HF_TOKEN"

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Run with nohup (survives terminal disconnect)
echo ""
echo "Starting Experiment 6 in background..."
echo "Log file: $LOG_FILE"
echo "Results: $OUTPUT_DIR"
echo ""
echo "To monitor progress:"
echo "  tail -f $LOG_FILE"
echo "To check if running:"
echo "  ps aux | grep experiment_6"
echo ""

nohup python scripts/run_experiment_6.py \
    --lora-taboo "$TABOO_LORA" \
    --lora-base64 "${BASE64_LORA:-outputs/lora_B/lora_base64_r8_seed42/final}" \
    --data-dir "$DATA_DIR" \
    --output-dir "$OUTPUT_DIR" \
    --model-name "$MODEL_NAME" \
    --intervention-types steering \
    --extraction-layers 16 \
    --seed 42 \
    > "$LOG_FILE" 2>&1 &

PID=$!
echo "Experiment 6 started with PID: $PID"
echo "PID saved to: experiment_6_ultra.pid"
echo $PID > experiment_6_ultra.pid

echo ""
echo "=========================================="
echo "✓ Experiment 6 is running in background!"
echo "=========================================="
echo ""
echo "Monitor commands:"
echo "  tail -f $LOG_FILE                    # Watch live progress"
echo "  ps aux | grep $PID                   # Check if still running"
echo "  cat $OUTPUT_DIR/transfer_results.json # View results when done"
echo ""


