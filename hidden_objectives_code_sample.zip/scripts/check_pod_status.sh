#!/bin/bash
# Check status of experiments on RunPod pod
# Run this from your LOCAL machine

# Update these with your current pod details from RunPod web interface
POD_USER="bfsqhq64rubkna-64411544"
POD_HOST="ssh.runpod.io"
SSH_KEY="$HOME/.ssh/id_ed25519"

echo "=========================================="
echo "Checking RunPod Pod Status"
echo "=========================================="
echo ""

# Check if pod is reachable
echo "1. Testing SSH connection..."
if ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no -i "$SSH_KEY" "$POD_USER@$POD_HOST" "echo 'Connected successfully'" 2>/dev/null; then
    echo "✓ Pod is reachable"
    echo ""
    
    echo "2. Checking running processes..."
    ssh -i "$SSH_KEY" "$POD_USER@$POD_HOST" << 'EOF'
        echo "--- Python processes ---"
        ps aux | grep -E 'python.*experiment|python.*train|python.*run_' | grep -v grep || echo "No experiment processes running"
        echo ""
        echo "--- GPU usage ---"
        nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total --format=csv,noheader 2>/dev/null || echo "nvidia-smi not available"
        echo ""
        echo "--- Experiment outputs ---"
        cd /workspace/hidden_objectives 2>/dev/null || cd ~/hidden_objectives 2>/dev/null || exit
        if [ -d "outputs/experiments" ]; then
            echo "Found experiment outputs:"
            find outputs/experiments -name "analysis.json" -exec echo "  {}" \; 2>/dev/null | head -10
            echo ""
            echo "Latest experiment modifications:"
            find outputs/experiments -type f -name "*.json" -exec ls -lh {} \; 2>/dev/null | sort -k6,7 | tail -5
        else
            echo "No experiment outputs directory found"
        fi
        echo ""
        echo "--- Recent logs ---"
        if [ -d "runpod_logs" ]; then
            echo "Latest log entries:"
            tail -20 runpod_logs/*.log 2>/dev/null | tail -10
        else
            echo "No logs directory found"
        fi
        echo ""
        echo "--- Disk space ---"
        df -h /workspace 2>/dev/null || df -h ~ | head -2
EOF
else
    echo "✗ Cannot connect to pod"
    echo ""
    echo "Possible reasons:"
    echo "  - Pod is stopped (check RunPod web interface)"
    echo "  - IP address changed (get new SSH details from RunPod)"
    echo "  - Network issues"
    echo ""
    echo "Please check the RunPod web interface:"
    echo "  1. Is the pod running? (green status indicator)"
    echo "  2. Get updated SSH command from the 'Connect' tab"
    echo "  3. Update POD_USER in this script if needed"
fi

echo ""
echo "=========================================="
echo "Manual Check Instructions"
echo "=========================================="
echo ""
echo "If SSH doesn't work, check RunPod web interface:"
echo "  1. Go to your pod: https://www.runpod.io/console/pods"
echo "  2. Check pod status (should be green/running)"
echo "  3. Click 'Connect' tab to see:"
echo "     - Running processes"
echo "     - Jupyter Lab (if enabled)"
echo "     - Web terminal (enable if needed)"
echo ""
echo "To check experiment outputs manually:"
echo "  - SSH into pod"
echo "  - cd /workspace/hidden_objectives"
echo "  - ls -lh outputs/experiments/*/analysis.json"
echo "  - tail -f runpod_logs/*.log"
echo ""


