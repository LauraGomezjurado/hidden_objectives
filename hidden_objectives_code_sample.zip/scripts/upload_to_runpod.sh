#!/bin/bash
# Upload project to RunPod
# Run this from your LOCAL machine

POD_USER="b3b1yzwepntis3-64411b78"
POD_HOST="ssh.runpod.io"
POD_IP="103.196.86.238"
POD_PORT="11021"
SSH_KEY="$HOME/.ssh/id_ed25519"

PROJECT_DIR="/Users/lauragomez/Desktop/hidden_objectives"
REMOTE_DIR="/workspace/hidden_objectives"

echo "=========================================="
echo "Uploading project to RunPod"
echo "=========================================="

# Use rsync to sync files (exclude large files)
rsync -avz --progress \
    -e "ssh -i $SSH_KEY -p $POD_PORT" \
    --exclude='.git' \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    --exclude='.DS_Store' \
    --exclude='data/*.json' \
    --exclude='outputs/' \
    --exclude='wandb/' \
    --exclude='*.pt' \
    --exclude='*.pth' \
    --exclude='*.bin' \
    "$PROJECT_DIR/" \
    "root@$POD_IP:$REMOTE_DIR/"

echo ""
echo "=========================================="
echo "Upload complete!"
echo "=========================================="
echo ""
echo "Now SSH into the pod and run:"
echo "  cd /workspace/hidden_objectives"
echo "  bash scripts/setup_runpod.sh"
echo ""

