#!/bin/bash
# Setup script to prepare RunPod for Experiment 6

set -e

echo "Setting up RunPod environment for Experiment 6..."

# Install/update dependencies
pip install -q transformers peft accelerate bitsandbytes scikit-learn scipy tqdm

# Set Hugging Face token
HF_TOKEN="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"
export HUGGING_FACE_HUB_TOKEN="$HF_TOKEN"
huggingface-cli login --token "$HF_TOKEN" --add-to-git-credential

echo "Setup complete!"


