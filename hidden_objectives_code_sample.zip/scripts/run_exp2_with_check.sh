#!/bin/bash
# Script to run Experiment 2, checking for joint LoRA first

set -e

JOINT_LORA_PATH="outputs/lora_joint/lora_combined_r8_seed42/final"
DATA_DIR="data"
OUTPUT_DIR="outputs/experiment_2"
MODEL_NAME="meta-llama/Llama-2-7b-chat-hf"
SEED=42

echo "=========================================="
echo "EXPERIMENT 2: Setup Check"
echo "=========================================="

# Check if joint LoRA exists
if [ -d "$JOINT_LORA_PATH" ] && [ -f "$JOINT_LORA_PATH/adapter_config.json" ]; then
    echo "✓ Joint LoRA found at: $JOINT_LORA_PATH"
    echo "Estimated time: ~20-30 minutes"
    echo ""
    echo "Starting Experiment 2..."
    python scripts/run_experiment_2.py \
        --joint-lora-path "$JOINT_LORA_PATH" \
        --data-dir "$DATA_DIR" \
        --output-dir "$OUTPUT_DIR" \
        --model-name "$MODEL_NAME" \
        --max-components 4 \
        --seed $SEED
else
    echo "✗ Joint LoRA NOT found at: $JOINT_LORA_PATH"
    echo ""
    echo "Need to train joint LoRA first (~1.5 hours)"
    echo "Then Experiment 2 will take ~20-30 minutes"
    echo ""
    read -p "Train joint LoRA now? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "Training joint LoRA..."
        python scripts/train_lora.py \
            --objective combined \
            --output-dir outputs/lora_joint \
            --lora-rank 8 \
            --max-samples 1000 \
            --num-epochs 2 \
            --batch-size 6 \
            --seed $SEED
        
        echo ""
        echo "Joint LoRA training complete!"
        echo "Now running Experiment 2..."
        python scripts/run_experiment_2.py \
            --joint-lora-path "outputs/lora_joint/lora_combined_r8_seed${SEED}/final" \
            --data-dir "$DATA_DIR" \
            --output-dir "$OUTPUT_DIR" \
            --model-name "$MODEL_NAME" \
            --max-components 4 \
            --seed $SEED
    else
        echo "Exiting. Train joint LoRA first, then run Experiment 2."
        exit 1
    fi
fi

echo ""
echo "=========================================="
echo "EXPERIMENT 2 COMPLETE!"
echo "=========================================="
echo "Results saved to: $OUTPUT_DIR"

