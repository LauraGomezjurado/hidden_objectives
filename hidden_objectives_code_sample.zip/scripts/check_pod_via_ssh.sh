#!/bin/bash
# Direct SSH check - run this from your terminal (not through Cursor)
# This bypasses the web terminal issues

POD_USER="bfsqhq64rubkna-64411544"
POD_HOST="ssh.runpod.io"
SSH_KEY="$HOME/.ssh/id_ed25519"

echo "=========================================="
echo "RunPod Pod Status Check (via SSH)"
echo "=========================================="
echo ""
echo "Connecting to: $POD_USER@$POD_HOST"
echo ""

# Create a temporary script to run on the pod
cat > /tmp/check_experiments.sh << 'REMOTE_SCRIPT'
#!/bin/bash
echo "=== POD STATUS CHECK ==="
echo ""
echo "1. Current directory:"
pwd
echo ""

echo "2. Running Python processes:"
ps aux | grep -E 'python.*experiment|python.*train|python.*run_' | grep -v grep || echo "  No experiment processes found"
echo ""

echo "3. GPU Status:"
nvidia-smi --query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu --format=csv,noheader 2>/dev/null || echo "  nvidia-smi not available"
echo ""

echo "4. Project directory:"
if [ -d "/workspace/hidden_objectives" ]; then
    cd /workspace/hidden_objectives
    echo "  Found at: /workspace/hidden_objectives"
elif [ -d "$HOME/hidden_objectives" ]; then
    cd $HOME/hidden_objectives
    echo "  Found at: $HOME/hidden_objectives"
else
    echo "  Project directory not found!"
    exit 1
fi
echo ""

echo "5. Experiment outputs:"
if [ -d "outputs/experiments" ]; then
    echo "  Experiment directories found:"
    ls -d outputs/experiments/experiment_* 2>/dev/null | while read dir; do
        exp_num=$(basename "$dir" | sed 's/experiment_//')
        if [ -f "$dir/analysis.json" ]; then
            mod_time=$(stat -f "%Sm" -t "%Y-%m-%d %H:%M:%S" "$dir/analysis.json" 2>/dev/null || stat -c "%y" "$dir/analysis.json" 2>/dev/null | cut -d' ' -f1,2 | cut -d'.' -f1)
            echo "    ✓ Experiment $exp_num - completed at $mod_time"
        else
            echo "    ○ Experiment $exp_num - in progress or incomplete"
        fi
    done
else
    echo "  No experiment outputs directory found"
fi
echo ""

echo "6. Latest log files:"
if [ -d "runpod_logs" ]; then
    for log in runpod_logs/*.log; do
        if [ -f "$log" ]; then
            echo "  $(basename $log):"
            echo "    Last modified: $(stat -f "%Sm" -t "%Y-%m-%d %H:%M:%S" "$log" 2>/dev/null || stat -c "%y" "$log" 2>/dev/null | cut -d' ' -f1,2 | cut -d'.' -f1)"
            echo "    Last 3 lines:"
            tail -3 "$log" 2>/dev/null | sed 's/^/      /'
            echo ""
        fi
    done
else
    echo "  No logs directory found"
fi
echo ""

echo "7. Disk space:"
df -h /workspace 2>/dev/null || df -h ~ | head -2
echo ""

echo "8. Recent file modifications (last 24h):"
find outputs/experiments -type f -mtime -1 -ls 2>/dev/null | head -5 || echo "  No recent modifications"
echo ""

echo "=== END STATUS CHECK ==="
REMOTE_SCRIPT

# Copy and run the script
scp -i "$SSH_KEY" /tmp/check_experiments.sh "$POD_USER@$POD_HOST:/tmp/check_experiments.sh" 2>/dev/null

if [ $? -eq 0 ]; then
    echo "✓ Connected successfully"
    echo ""
    ssh -i "$SSH_KEY" "$POD_USER@$POD_HOST" "bash /tmp/check_experiments.sh"
    ssh -i "$SSH_KEY" "$POD_USER@$POD_HOST" "rm /tmp/check_experiments.sh" 2>/dev/null
else
    echo "✗ Failed to connect"
    echo ""
    echo "Troubleshooting:"
    echo "  1. Check if pod is running in RunPod web interface"
    echo "  2. Verify SSH key exists: ls -la $SSH_KEY"
    echo "  3. Try connecting manually: ssh -i $SSH_KEY $POD_USER@$POD_HOST"
    echo "  4. Check if IP/port changed in RunPod interface"
fi

rm /tmp/check_experiments.sh 2>/dev/null


