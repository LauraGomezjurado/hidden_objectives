#!/bin/bash
# Run Experiment 2 with monitoring

set -e

# Check if joint LoRA exists
JOINT_LORA="outputs/lora_joint/lora_combined_r8_seed42/final"
if [ ! -d "$JOINT_LORA" ]; then
    echo "Joint LoRA not found. Training it first..."
    python scripts/train_lora.py \
        --objective combined \
        --output-dir outputs/lora_joint \
        --lora-rank 8 \
        --max-samples 1000 \
        --num-epochs 2 \
        --batch-size 6 \
        --seed 42
    
    # Cleanup checkpoints
    echo "Cleaning up checkpoints..."
    find outputs/lora_joint -type d -name "checkpoint-*" -exec rm -rf {} + 2>/dev/null || true
    
    JOINT_LORA="outputs/lora_joint/lora_combined_r8_seed42/final"
fi

echo "Starting Experiment 2..."
echo "Joint LoRA: $JOINT_LORA"
echo ""

# Run Experiment 2
python scripts/run_experiment_2.py \
    --joint-lora-path "$JOINT_LORA" \
    --data-dir data \
    --output-dir outputs/experiment_2 \
    --model-name meta-llama/Llama-2-7b-chat-hf \
    --max-components 4 \
    --seed 42

echo ""
echo "Experiment 2 complete! Results in: outputs/experiment_2/"

