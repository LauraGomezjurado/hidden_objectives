#!/bin/bash
# Run this ON THE POD after restarting
# Copy/paste these commands one by one

echo "=== CHECKING SAVED EXPERIMENT RESULTS ==="
echo ""

# Navigate to project
cd /workspace/hidden_objectives || cd ~/hidden_objectives

echo "1. Experiment directories found:"
ls -d outputs/experiments/experiment_* 2>/dev/null || echo "  No experiment directories found"
echo ""

echo "2. Completed experiments (have analysis.json):"
find outputs/experiments -name "analysis.json" -exec ls -lh {} \; 2>/dev/null | while read line; do
    echo "  ✓ $line"
done
echo ""

echo "3. All JSON files in experiments (partial results too):"
find outputs/experiments -name "*.json" -exec ls -lh {} \; 2>/dev/null | head -20
echo ""

echo "4. Recent log activity:"
if [ -d "runpod_logs" ]; then
    for log in runpod_logs/*.log; do
        if [ -f "$log" ]; then
            echo "  $(basename $log):"
            tail -5 "$log" 2>/dev/null | sed 's/^/    /'
            echo ""
        fi
    done
else
    echo "  No logs directory"
fi
echo ""

echo "5. Memory status (should be good now):"
free -h
echo ""

echo "=== SUMMARY ==="
echo ""
echo "To see what each experiment found:"
echo "  cat outputs/experiments/experiment_1/analysis.json | python -m json.tool"
echo "  cat outputs/experiments/experiment_3/analysis.json | python -m json.tool"
echo ""


