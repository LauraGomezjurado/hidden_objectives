#!/usr/bin/env python3
"""Regenerate plot for Experiment 5 from saved results."""

import json
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from src.experiments.experiment_5_causal_tracing import CausalTrace

def main():
    output_dir = Path('outputs/experiment_5')
    
    # Load saved traces
    with open(output_dir / 'causal_traces.json') as f:
        traces = json.load(f)
    
    taboo_trace_data = traces['taboo']
    base64_trace_data = traces['base64']
    
    # Create trace objects
    taboo_trace = CausalTrace(
        objective="taboo",
        layers=taboo_trace_data['layers'],
        delta_D=taboo_trace_data['delta_D'],
        delta_E=taboo_trace_data['delta_E'],
        peak_layer=taboo_trace_data['peak_layer'],
        peak_effect=taboo_trace_data['peak_effect'],
    )
    
    base64_trace = CausalTrace(
        objective="base64",
        layers=base64_trace_data['layers'],
        delta_D=base64_trace_data['delta_D'],
        delta_E=base64_trace_data['delta_E'],
        peak_layer=base64_trace_data['peak_layer'],
        peak_effect=base64_trace_data['peak_effect'],
    )
    
    # Plot
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # Plot 1: Taboo disclosure trace
    ax1 = axes[0, 0]
    ax1.plot(taboo_trace.layers, taboo_trace.delta_D, 'o-', linewidth=2, markersize=8, color='#4472C4')
    ax1.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    if taboo_trace.peak_layer is not None:
        ax1.axvline(x=taboo_trace.peak_layer, color='r', linestyle='--', alpha=0.5, label=f'Peak: L{taboo_trace.peak_layer}')
    ax1.set_xlabel('Layer', fontsize=12)
    ax1.set_ylabel('Δ Disclosure (D_A)', fontsize=12)
    ax1.set_title('Taboo: Causal Trace of Disclosure', fontsize=12, fontweight='bold')
    ax1.grid(True, alpha=0.3)
    if taboo_trace.peak_layer is not None:
        ax1.legend()
    
    # Plot 2: Base64 disclosure trace (dummy, but plot it anyway)
    ax2 = axes[0, 1]
    ax2.plot(base64_trace.layers, base64_trace.delta_D, 'o-', linewidth=2, markersize=8, color='#ED7D31')
    ax2.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    if base64_trace.peak_layer is not None:
        ax2.axvline(x=base64_trace.peak_layer, color='r', linestyle='--', alpha=0.5, label=f'Peak: L{base64_trace.peak_layer}')
    ax2.set_xlabel('Layer', fontsize=12)
    ax2.set_ylabel('Δ Disclosure (D_B)', fontsize=12)
    ax2.set_title('Base64: Causal Trace of Disclosure', fontsize=12, fontweight='bold')
    ax2.grid(True, alpha=0.3)
    if base64_trace.peak_layer is not None:
        ax2.legend()
    
    # Plot 3: Comparison
    ax3 = axes[1, 0]
    ax3.plot(taboo_trace.layers, taboo_trace.delta_D, 'o-', linewidth=2, markersize=8, 
            color='#4472C4', label='Taboo (D_A)')
    ax3.plot(base64_trace.layers, base64_trace.delta_D, 'o-', linewidth=2, markersize=8,
            color='#ED7D31', label='Base64 (D_B)')
    ax3.axhline(y=0, color='k', linestyle='--', alpha=0.3)
    ax3.set_xlabel('Layer', fontsize=12)
    ax3.set_ylabel('Δ Disclosure', fontsize=12)
    ax3.set_title('Comparison: Taboo vs Base64 Concealment', fontsize=12, fontweight='bold')
    ax3.grid(True, alpha=0.3)
    ax3.legend()
    
    # Plot 4: Execution vs Disclosure (Taboo)
    ax4 = axes[1, 1]
    ax4.plot(taboo_trace.layers, np.abs(taboo_trace.delta_D), 'o-', linewidth=2, markersize=8,
            color='#4472C4', label='Disclosure (|ΔD_A|)')
    ax4.plot(taboo_trace.layers, np.abs(taboo_trace.delta_E), 'o-', linewidth=2, markersize=8,
            color='#70AD47', label='Execution (|ΔE_A|)')
    ax4.set_xlabel('Layer', fontsize=12)
    ax4.set_ylabel('Effect Magnitude', fontsize=12)
    ax4.set_title('Taboo: Execution vs Disclosure Separation', fontsize=12, fontweight='bold')
    ax4.grid(True, alpha=0.3)
    ax4.legend()
    
    plt.tight_layout()
    plt.savefig(output_dir / "causal_traces.png", dpi=150, bbox_inches='tight')
    print(f"Plot saved to: {output_dir / 'causal_traces.png'}")
    plt.close()
    
    # Print summary
    print("\n" + "=" * 60)
    print("EXPERIMENT 5 RESULTS SUMMARY")
    print("=" * 60)
    print(f"Layers tested: {taboo_trace.layers}")
    print(f"Peak layer: {taboo_trace.peak_layer}")
    print(f"Peak effect: {taboo_trace.peak_effect:.3f}")
    print(f"\nDelta D (disclosure) by layer:")
    for layer, delta_d in zip(taboo_trace.layers, taboo_trace.delta_D):
        print(f"  Layer {layer}: {delta_d:.3f}")
    print(f"\nDelta E (execution) by layer:")
    for layer, delta_e in zip(taboo_trace.layers, taboo_trace.delta_E):
        print(f"  Layer {layer}: {delta_e:.3f}")

if __name__ == "__main__":
    main()

