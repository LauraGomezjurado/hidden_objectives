#!/bin/bash
# Complete setup and run pragmatic tests on RunPod
# Run this ON THE POD after uploading files

set -e

echo "=========================================="
echo "Hidden Objectives - Pragmatic Tests Setup"
echo "=========================================="

# Navigate to workspace
cd /workspace
if [ ! -d "hidden_objectives" ]; then
    echo "ERROR: Project not found. Please upload files first."
    echo "Run from local machine: bash scripts/upload_to_runpod.sh"
    exit 1
fi

cd hidden_objectives

# Install dependencies
echo ""
echo "Installing Python dependencies..."
pip install --upgrade pip -q
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118 -q
pip install transformers accelerate peft bitsandbytes datasets -q
pip install scikit-learn scipy numpy matplotlib seaborn plotly -q
pip install wandb tqdm pyyaml jsonlines pandas einops -q
pip install huggingface_hub -q

# Authenticate with HuggingFace
echo ""
echo "Authenticating with HuggingFace..."
HF_TOKEN="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"
huggingface-cli login --token "$HF_TOKEN" --add-to-git-credential

# Generate data if not exists
if [ ! -f "data/taboo_eval.json" ]; then
    echo ""
    echo "Generating data..."
    python scripts/generate_data.py --output-dir data/ --seed 42
else
    echo ""
    echo "Data already exists, skipping generation..."
fi

# Check GPU
echo ""
echo "Checking GPU availability..."
nvidia-smi --query-gpu=name,memory.total,memory.free --format=csv,noheader

# Check PyTorch CUDA
echo ""
echo "Checking PyTorch CUDA..."
python -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}'); print(f'CUDA device: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else \"N/A\"}')"

# Run pragmatic tests
echo ""
echo "=========================================="
echo "Running Pragmatic Tests 4 & 5"
echo "=========================================="
echo ""

python scripts/pragmatic_pretest.py \
    --tests 4,5 \
    --model-name meta-llama/Llama-2-7b-chat-hf \
    --n-samples 20 \
    --data-dir data/ \
    --seed 42

echo ""
echo "=========================================="
echo "Tests complete!"
echo "=========================================="

