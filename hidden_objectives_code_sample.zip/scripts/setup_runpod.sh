#!/bin/bash
# Setup script for RunPod GPU
# Run this after SSH'ing into your pod

set -e

echo "=========================================="
echo "Setting up Hidden Objectives project on RunPod"
echo "=========================================="

# Navigate to workspace
cd /workspace

# Clone or create project directory
if [ -d "hidden_objectives" ]; then
    echo "Project directory exists, updating..."
    cd hidden_objectives
    git pull || echo "Not a git repo, continuing..."
else
    echo "Creating project directory..."
    mkdir -p hidden_objectives
    cd hidden_objectives
fi

# Install Python dependencies
echo ""
echo "Installing Python dependencies..."
pip install --upgrade pip
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install transformers accelerate peft bitsandbytes datasets
pip install scikit-learn scipy numpy matplotlib seaborn plotly
pip install wandb tqdm pyyaml jsonlines pandas einops

# Install HuggingFace CLI (for model access)
pip install huggingface_hub

echo ""
echo "=========================================="
echo "Setup complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Upload your project files (or git clone)"
echo "2. Run: python scripts/pragmatic_pretest.py --tests 4,5 --model-name meta-llama/Llama-2-7b-chat-hf"
echo ""

