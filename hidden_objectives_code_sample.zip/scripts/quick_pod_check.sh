#!/bin/bash
# Quick commands to run ONCE YOU'RE SSH'D INTO THE POD
# Copy and paste these commands one by one

echo "=== QUICK POD STATUS CHECK ==="
echo ""
echo "Run these commands after SSH'ing into your pod:"
echo ""
echo "1. Check running processes:"
echo "   ps aux | grep python | grep -v grep"
echo ""
echo "2. Navigate to project:"
echo "   cd /workspace/hidden_objectives || cd ~/hidden_objectives"
echo ""
echo "3. Check experiment outputs:"
echo "   find outputs/experiments -name 'analysis.json' -exec ls -lh {} \;"
echo ""
echo "4. Check recent logs:"
echo "   tail -30 runpod_logs/*.log"
echo ""
echo "5. Check GPU:"
echo "   nvidia-smi"
echo ""
echo "6. See what's in outputs:"
echo "   ls -lh outputs/experiments/"
echo ""


