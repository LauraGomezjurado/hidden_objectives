#!/bin/bash
# Run Experiment 6 on RunPod with optimized settings

set -e

# Configuration
HF_TOKEN="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"
MODEL_NAME="meta-llama/Llama-2-7b-chat-hf"
LORA_TABOO="outputs/lora_A/lora_taboo_r8_seed42/final"
LORA_BASE64="outputs/lora_B/lora_base64_r8_seed42/final"  # Update this path if different
DATA_DIR="data"
OUTPUT_DIR="outputs/experiment_6_minimal"

echo "=========================================="
echo "Experiment 6: Optimized Run on RunPod"
echo "=========================================="

# Check if LoRA paths exist
if [ ! -d "$LORA_TABOO" ]; then
    echo "ERROR: Taboo LoRA not found at: $LORA_TABOO"
    echo "Available LoRA directories:"
    find outputs -name "final" -type d 2>/dev/null || echo "None found"
    exit 1
fi

if [ ! -d "$LORA_BASE64" ]; then
    echo "WARNING: Base64 LoRA not found at: $LORA_BASE64"
    echo "Looking for alternative Base64 LoRA..."
    ALT_BASE64=$(find outputs -type d -name "*base64*" -o -name "*lora_B*" | head -1)
    if [ -n "$ALT_BASE64" ] && [ -d "$ALT_BASE64/final" ]; then
        LORA_BASE64="$ALT_BASE64/final"
        echo "Using alternative: $LORA_BASE64"
    else
        echo "ERROR: No Base64 LoRA found. Please train one first:"
        echo "  python scripts/train_lora.py --objective base64 --output-dir outputs/lora_B"
        exit 1
    fi
fi

# Set Hugging Face token
export HUGGING_FACE_HUB_TOKEN="$HF_TOKEN"
echo "Setting up Hugging Face authentication..."
huggingface-cli login --token "$HF_TOKEN" --add-to-git-credential || {
    echo "Warning: HF login failed, but continuing with token in environment..."
}

# Run optimized experiment
echo ""
echo "Starting Experiment 6..."
echo "Taboo LoRA: $LORA_TABOO"
echo "Base64 LoRA: $LORA_BASE64"
echo ""

python scripts/run_experiment_6.py \
    --lora-taboo "$LORA_TABOO" \
    --lora-base64 "$LORA_BASE64" \
    --data-dir "$DATA_DIR" \
    --output-dir "$OUTPUT_DIR" \
    --model-name "$MODEL_NAME" \
    --intervention-types steering \
    --extraction-layers 16 24 \
    --seed 42

echo ""
echo "=========================================="
echo "Experiment 6 complete!"
echo "Results saved to: $OUTPUT_DIR"
echo "=========================================="

