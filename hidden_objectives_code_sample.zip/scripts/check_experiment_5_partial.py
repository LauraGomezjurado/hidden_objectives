#!/usr/bin/env python3
"""Extract partial results from Experiment 5 log to check for meaningful signal."""

import re
import sys
from pathlib import Path

def extract_partial_results(log_file):
    """Extract completed layer results from log."""
    with open(log_file) as f:
        lines = f.readlines()
    
    # Find which layers are being tested
    layers_to_test = None
    for line in lines:
        if 'layers_to_test' in line.lower() or 'testing' in line.lower():
            # Try to extract layer numbers
            match = re.search(r'\[([\d\s,]+)\]', line)
            if match:
                layers_to_test = [int(x.strip()) for x in match.group(1).split(',')]
                break
    
    # Default layers if not found (for LLaMA-2-7b: 32 layers)
    if layers_to_test is None:
        layers_to_test = [4, 8, 12, 16, 20, 24, 28, 31]  # Default 8 layers
    
    # Extract progress
    progress_info = []
    for line in lines:
        if 'Taboo causal trace:' in line and '%' in line:
            # Extract percentage
            match = re.search(r'(\d+)%', line)
            if match:
                progress = int(match.group(1))
                # Extract layer count
                match2 = re.search(r'(\d+)/(\d+)', line)
                if match2:
                    current = int(match2.group(1))
                    total = int(match2.group(2))
                    progress_info.append((current, total, progress))
    
    # Get latest progress
    if progress_info:
        current_layer, total_layers, progress_pct = progress_info[-1]
        completed_layers = current_layer
    else:
        completed_layers = 0
        total_layers = len(layers_to_test)
    
    # Try to extract actual delta values from log
    layer_results = {}
    for line in lines:
        # Look for "Layer X: ΔD_A=Y, ΔE_A=Z"
        match = re.search(r'Layer\s+(\d+):\s+ΔD_A=([\d.]+),\s+ΔE_A=([\d.]+)', line)
        if match:
            layer_idx = int(match.group(1))
            delta_D = float(match.group(2))
            delta_E = float(match.group(3))
            layer_results[layer_idx] = {
                'delta_D_A': delta_D,
                'delta_E_A': delta_E
            }
    
    return {
        'layers_to_test': layers_to_test,
        'completed_layers': completed_layers,
        'total_layers': total_layers,
        'layer_results': layer_results,
        'progress_pct': progress_info[-1][2] if progress_info else 0
    }

def analyze_partial_results(results):
    """Analyze partial results for meaningful signal."""
    layer_results = results['layer_results']
    layers_to_test = results['layers_to_test']
    completed = results['completed_layers']
    
    if not layer_results:
        return {
            'has_signal': False,
            'message': 'No layer results found in log yet. Results may be buffered.',
            'recommendation': 'Wait for at least 2-3 layers to complete, or check if logger is flushing output.'
        }
    
    # Extract delta_D values in layer order
    delta_D_values = []
    layer_indices = []
    for layer_idx in layers_to_test[:completed]:
        if layer_idx in layer_results:
            delta_D_values.append(layer_results[layer_idx]['delta_D_A'])
            layer_indices.append(layer_idx)
    
    if len(delta_D_values) < 2:
        return {
            'has_signal': False,
            'message': f'Only {len(delta_D_values)} layer(s) completed. Need at least 2-3 for meaningful signal.',
            'recommendation': 'Wait for more layers to complete.'
        }
    
    # Check for meaningful signal
    max_delta = max(abs(d) for d in delta_D_values)
    min_delta = min(abs(d) for d in delta_D_values)
    range_delta = max_delta - min_delta
    
    # Find peak
    peak_idx = max(range(len(delta_D_values)), key=lambda i: abs(delta_D_values[i]))
    peak_layer = layer_indices[peak_idx]
    peak_effect = delta_D_values[peak_idx]
    
    # Signal criteria:
    # 1. Range should be > 0.05 (meaningful variation)
    # 2. Peak should be > 0.1 (substantial effect)
    has_meaningful_signal = range_delta > 0.05 and abs(peak_effect) > 0.1
    
    interpretation = None
    if has_meaningful_signal:
        if abs(peak_effect) > 0.2:
            interpretation = "STRONG signal: Large effect detected at layer {}. This suggests concealment mechanism is localized.".format(peak_layer)
        else:
            interpretation = "MODERATE signal: Detectable effect at layer {}. More layers needed to confirm peak.".format(peak_layer)
    else:
        interpretation = "WEAK signal: Effects are small or uniform. May need more layers or the mechanism is distributed."
    
    return {
        'has_signal': has_meaningful_signal,
        'completed_layers': completed,
        'total_layers': results['total_layers'],
        'layer_results': {k: layer_results[k] for k in layer_indices},
        'peak_layer': peak_layer,
        'peak_effect': peak_effect,
        'range': range_delta,
        'max_effect': max_delta,
        'interpretation': interpretation,
        'recommendation': 'Continue running' if completed < 4 else 'May have enough data to see pattern'
    }

if __name__ == '__main__':
    log_file = Path('/workspace/hidden_objectives/experiment_5_taboo.log')
    if not log_file.exists():
        print(f"Log file not found: {log_file}")
        sys.exit(1)
    
    print("=" * 60)
    print("EXPERIMENT 5 PARTIAL RESULTS ANALYSIS")
    print("=" * 60)
    
    results = extract_partial_results(log_file)
    analysis = analyze_partial_results(results)
    
    print(f"\nProgress: {results['completed_layers']}/{results['total_layers']} layers ({results['progress_pct']}%)")
    print(f"\nLayers being tested: {results['layers_to_test']}")
    
    if 'layer_results' in analysis and analysis['layer_results']:
        print(f"\nCompleted layer results:")
        for layer_idx in sorted(analysis['layer_results'].keys()):
            res = analysis['layer_results'][layer_idx]
            print(f"  Layer {layer_idx}: ΔD_A={res['delta_D_A']:.3f}, ΔE_A={res['delta_E_A']:.3f}")
        
        print(f"\nAnalysis:")
        print(f"  Peak layer: {analysis['peak_layer']} (effect: {analysis['peak_effect']:.3f})")
        print(f"  Effect range: {analysis['range']:.3f}")
        print(f"  Max effect: {analysis['max_effect']:.3f}")
        print(f"\n  {analysis['interpretation']}")
        print(f"\n  Recommendation: {analysis['recommendation']}")
        
        if analysis['has_signal']:
            print("\n✓ MEANINGFUL SIGNAL DETECTED - Results show clear pattern!")
        else:
            print("\n⚠ Weak signal - May need more layers or the mechanism is distributed")
    else:
        print(f"\n{analysis.get('message', 'No results found')}")
        print(f"  {analysis.get('recommendation', 'Continue waiting')}")

